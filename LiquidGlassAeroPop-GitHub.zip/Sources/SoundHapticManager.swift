import Foundation
import AVFoundation
import UIKit

final class SoundHapticManager {
    static let shared = SoundHapticManager()
    private var engine = AVAudioEngine()
    private var playerNode = AVAudioPlayerNode()
    private let sampleRate: Double = 44100.0
    private var isSetup = false

    private init() {
        setupAudio()
    }

    private func setupAudio() {
        do {
            try AVAudioSession.sharedInstance().setCategory(.ambient, mode: .default, options: [.mixWithOthers])
            try AVAudioSession.sharedInstance().setActive(true)
            
            let format = AVAudioFormat(standardFormatWithSampleRate: sampleRate, channels: 1)!
            engine.attach(playerNode)
            engine.connect(playerNode, to: engine.mainMixerNode, format: format)
            try engine.start()
            playerNode.play()
            isSetup = true
        } catch {
            isSetup = false
        }
    }

    func playPop(pitchMultiplier: Float = 1.0, isGolden: Bool = false) {
        let generator = UIImpactFeedbackGenerator(style: isGolden ? .heavy : .light)
        generator.impactOccurred()

        guard isSetup else { return }
        if !engine.isRunning {
            try? engine.start()
            playerNode.play()
        }

        let duration: Double = isGolden ? 0.16 : 0.085
        let frameCount = AVAudioFrameCount(sampleRate * duration)
        let format = AVAudioFormat(standardFormatWithSampleRate: sampleRate, channels: 1)!
        guard let buffer = AVAudioPCMBuffer(pcmFormat: format, frameCapacity: frameCount) else { return }
        buffer.frameLength = frameCount

        let data = buffer.floatChannelData![0]
        let baseFreq: Double = (isGolden ? 520.0 : 380.0) * Double(pitchMultiplier)
        let endFreq: Double = baseFreq * 2.4

        for i in 0..<Int(frameCount) {
            let t = Double(i) / sampleRate
            let progress = t / duration
            // Fast upward frequency sweep for classic water/glass bubble pop
            let currentFreq = baseFreq + (endFreq - baseFreq) * pow(progress, 0.65)
            let phase = 2.0 * Double.pi * currentFreq * t
            let envelope = sin(Double.pi * min(progress * 6.0, 1.0)) * exp(-progress * 5.5)
            var sample = sin(phase) * envelope * 0.35
            if isGolden {
                sample += sin(phase * 1.5) * envelope * 0.2
            }
            data[i] = Float(sample)
        }

        playerNode.scheduleBuffer(buffer, at: nil, options: [], completionHandler: nil)
    }

    func playUpgrade() {
        let generator = UINotificationFeedbackGenerator()
        generator.notificationOccurred(.success)
    }

    func playWin() {
        let generator = UINotificationFeedbackGenerator()
        generator.notificationOccurred(.success)
    }
}
