import SwiftUI

@main
struct LiquidGlassAeroPopApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
                .preferredColorScheme(.dark)
        }
    }
}
