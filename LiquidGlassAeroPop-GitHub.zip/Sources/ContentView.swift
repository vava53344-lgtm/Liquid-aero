import SwiftUI

struct ContentView: View {
    @StateObject private var engine = AeroGameEngine()
    @State private var showUpgradesSheet = false

    var body: some View {
        GeometryReader { geo in
            ZStack {
                // Frutiger Aero Animated Wallpaper
                FrutigerAeroWallpaperView()

                // Bubbles Layer
                ForEach(engine.bubbles) { bubble in
                    LiquidGlassBubbleView(bubble: bubble) {
                        engine.popBubble(id: bubble.id)
                    }
                }

                // Splash Particles Layer
                ForEach(engine.particles) { particle in
                    Circle()
                        .fill(particle.color.opacity(particle.life))
                        .frame(width: particle.size, height: particle.size)
                        .position(x: particle.x, y: particle.y)
                        .allowsHitTesting(false)
                }

                // Floating Score Popups
                ForEach(engine.floatingScores) { score in
                    Text(score.text)
                        .font(.system(size: 18, weight: .heavy, design: .rounded))
                        .foregroundStyle(score.color)
                        .shadow(color: .black.opacity(0.35), radius: 3, x: 0, y: 2)
                        .opacity(score.life)
                        .position(x: score.x, y: score.y)
                        .allowsHitTesting(false)
                }

                // Liquid Glass HUD Overlay
                VStack(spacing: 12) {
                    topHUD
                    Spacer()
                    bottomControlBar
                }
                .padding(.horizontal, 16)
                .padding(.top, 10)
                .padding(.bottom, 16)

                // Victory Overlay Modal
                if engine.showWinBanner {
                    victoryOverlay
                        .transition(.scale.combined(with: .opacity))
                        .zIndex(10)
                }
            }
            .onAppear {
                engine.screenSize = geo.size
                engine.start()
            }
            .onChange(of: geo.size) { newSize in
                engine.screenSize = newSize
            }
            .sheet(isPresented: $showUpgradesSheet) {
                UpgradesSheetView(engine: engine)
                    .presentationDetents([.medium, .large])
                    .presentationDragIndicator(.visible)
            }
        }
    }

    private var topHUD: some View {
        VStack(spacing: 10) {
            HStack {
                // Energy Counter
                HStack(spacing: 8) {
                    ZStack {
                        Circle()
                            .fill(
                                LinearGradient(
                                    colors: [Color.cyan, Color.blue],
                                    startPoint: .topLeading,
                                    endPoint: .bottomTrailing
                                )
                            )
                            .frame(width: 34, height: 34)
                        Image(systemName: "drop.fill")
                            .foregroundStyle(.white)
                            .font(.system(size: 16, weight: .bold))
                    }

                    VStack(alignment: .leading, spacing: 1) {
                        Text("AERO ЭНЕРГИЯ")
                            .font(.system(size: 10, weight: .bold, design: .rounded))
                            .foregroundStyle(.white.opacity(0.8))
                        Text("\(Int(engine.energy))")
                            .font(.system(size: 22, weight: .heavy, design: .rounded))
                            .foregroundStyle(.white)
                            .contentTransition(.numericText())
                    }
                }

                Spacer()

                // Popped Stats Pill
                VStack(alignment: .trailing, spacing: 2) {
                    Text("ЛОПНУТО: \(engine.bubblesPopped)")
                        .font(.system(size: 12, weight: .bold, design: .rounded))
                        .foregroundStyle(.white)
                    Text("+\(Int(engine.pointsPerPop)) / тап")
                        .font(.system(size: 11, weight: .semibold, design: .rounded))
                        .foregroundStyle(Color(red: 0.75, green: 1.0, blue: 0.75))
                }
            }

            // Progress Bar to Win
            VStack(alignment: .leading, spacing: 4) {
                HStack {
                    Text(engine.hasWon ? "ЦЕЛЬ ДОСТИГНУТА! БЕСКОНЕЧНЫЙ РЕЖИМ" : "ПРОГРЕСС ДО ПОБЕДЫ")
                        .font(.system(size: 10, weight: .heavy, design: .rounded))
                        .foregroundStyle(.white.opacity(0.9))
                    Spacer()
                    Text("\(Int(engine.totalEarned)) / \(Int(engine.winGoal))")
                        .font(.system(size: 10, weight: .bold, design: .rounded))
                        .foregroundStyle(.white)
                }

                GeometryReader { barGeo in
                    ZStack(alignment: .leading) {
                        Capsule()
                            .fill(Color.black.opacity(0.25))

                        Capsule()
                            .fill(
                                LinearGradient(
                                    colors: [
                                        Color(red: 0.45, green: 1.0, blue: 0.35),
                                        Color(red: 0.15, green: 0.90, blue: 1.0)
                                    ],
                                    startPoint: .leading,
                                    endPoint: .trailing
                                )
                            )
                            .frame(width: max(12, barGeo.size.width * engine.progressToWin))
                            .animation(.spring(response: 0.35), value: engine.progressToWin)
                    }
                }
                .frame(height: 10)
            }
        }
        .padding(14)
        .liquidGlass(cornerRadius: 24, tint: .cyan)
    }

    private var bottomControlBar: some View {
        HStack(spacing: 12) {
            Button {
                showUpgradesSheet = true
            } label: {
                HStack(spacing: 8) {
                    Image(systemName: "sparkles")
                        .font(.system(size: 18, weight: .bold))
                    Text("Улучшения")
                        .font(.system(size: 16, weight: .bold, design: .rounded))

                    // Badge if any upgrade is affordable
                    let affordableCount = UpgradeType.allCases.filter { engine.canAfford($0) }.count
                    if affordableCount > 0 {
                        Text("\(affordableCount)")
                            .font(.system(size: 12, weight: .heavy, design: .rounded))
                            .foregroundStyle(.black)
                            .padding(.horizontal, 7)
                            .padding(.vertical, 2)
                            .background(Color(red: 0.55, green: 1.0, blue: 0.35))
                            .clipShape(Capsule())
                    }
                }
                .foregroundStyle(.white)
                .frame(maxWidth: .infinity)
                .padding(.vertical, 14)
                .liquidGlass(cornerRadius: 22, tint: .green)
            }
            .buttonStyle(.plain)

            Button {
                engine.spawnBubble(randomY: false)
            } label: {
                Image(systemName: "plus.circle.fill")
                    .font(.system(size: 22, weight: .bold))
                    .foregroundStyle(.white)
                    .padding(14)
                    .liquidGlass(cornerRadius: 22, tint: .cyan)
            }
            .buttonStyle(.plain)
        }
    }

    private var victoryOverlay: some View {
        ZStack {
            Color.black.opacity(0.45)
                .ignoresSafeArea()

            VStack(spacing: 18) {
                ZStack {
                    Circle()
                        .fill(
                            LinearGradient(
                                colors: [Color.yellow, Color.green, Color.cyan],
                                startPoint: .topLeading,
                                endPoint: .bottomTrailing
                            )
                        )
                        .frame(width: 84, height: 84)
                        .shadow(color: .cyan.opacity(0.6), radius: 16)

                    Image(systemName: "trophy.fill")
                        .font(.system(size: 40))
                        .foregroundStyle(.white)
                }

                Text("ПОБЕДА В AERO-МИРЕ!")
                    .font(.system(size: 24, weight: .heavy, design: .rounded))
                    .foregroundStyle(.white)
                    .multilineTextAlignment(.center)

                Text("Ты собрал \(Int(engine.winGoal)) Aero-энергии и лопнул \(engine.bubblesPopped) стеклянных пузырей! Гармония будущего восстановлена.")
                    .font(.system(size: 15, weight: .medium, design: .rounded))
                    .foregroundStyle(.white.opacity(0.9))
                    .multilineTextAlignment(.center)

                VStack(spacing: 10) {
                    Button {
                        withAnimation {
                            engine.showWinBanner = false
                            engine.endlessMode = true
                        }
                    } label: {
                        Text("Продолжить игру")
                            .font(.system(size: 16, weight: .bold, design: .rounded))
                            .foregroundStyle(.black)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 14)
                            .background(
                                LinearGradient(
                                    colors: [Color(red: 0.6, green: 1.0, blue: 0.4), Color.cyan],
                                    startPoint: .leading,
                                    endPoint: .trailing
                                )
                            )
                            .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
                    }

                    Button {
                        withAnimation {
                            engine.resetGame()
                        }
                    } label: {
                        Text("Начать заново")
                            .font(.system(size: 15, weight: .bold, design: .rounded))
                            .foregroundStyle(.white)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 12)
                            .liquidGlass(cornerRadius: 18, tint: .white)
                    }
                }
            }
            .padding(24)
            .liquidGlass(cornerRadius: 32, tint: .cyan)
            .padding(.horizontal, 24)
        }
    }
}

struct UpgradesSheetView: View {
    @ObservedObject var engine: AeroGameEngine
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        ZStack {
            LinearGradient(
                colors: [
                    Color(red: 0.04, green: 0.34, blue: 0.68),
                    Color(red: 0.08, green: 0.62, blue: 0.72),
                    Color(red: 0.14, green: 0.56, blue: 0.28)
                ],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .ignoresSafeArea()

            VStack(spacing: 16) {
                HStack {
                    VStack(alignment: .leading, spacing: 2) {
                        Text("Улучшения Liquid Glass")
                            .font(.system(size: 22, weight: .heavy, design: .rounded))
                            .foregroundStyle(.white)
                        Text("Баланс: \(Int(engine.energy)) Aero-энергии")
                            .font(.system(size: 14, weight: .semibold, design: .rounded))
                            .foregroundStyle(Color(red: 0.65, green: 1.0, blue: 0.75))
                    }
                    Spacer()
                    Button {
                        dismiss()
                    } label: {
                        Image(systemName: "xmark.circle.fill")
                            .font(.system(size: 26))
                            .foregroundStyle(.white.opacity(0.8))
                    }
                }
                .padding(.top, 16)

                ScrollView {
                    VStack(spacing: 12) {
                        ForEach(UpgradeType.allCases) { type in
                            upgradeRow(type)
                        }
                    }
                }
            }
            .padding(.horizontal, 18)
        }
    }

    private func upgradeRow(_ type: UpgradeType) -> some View {
        let lvl = engine.level(for: type)
        let price = engine.cost(for: type)
        let affordable = engine.canAfford(type)

        return HStack(spacing: 14) {
            ZStack {
                RoundedRectangle(cornerRadius: 16, style: .continuous)
                    .fill(
                        LinearGradient(
                            colors: [Color.cyan.opacity(0.8), Color.green.opacity(0.7)],
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        )
                    )
                    .frame(width: 50, height: 50)
                Image(systemName: type.icon)
                    .font(.system(size: 22, weight: .bold))
                    .foregroundStyle(.white)
            }

            VStack(alignment: .leading, spacing: 3) {
                HStack(spacing: 6) {
                    Text(type.rawValue)
                        .font(.system(size: 16, weight: .bold, design: .rounded))
                        .foregroundStyle(.white)
                    Text("Ур. \(lvl)")
                        .font(.system(size: 11, weight: .heavy, design: .rounded))
                        .foregroundStyle(.black)
                        .padding(.horizontal, 6)
                        .padding(.vertical, 2)
                        .background(Color.white.opacity(0.85))
                        .clipShape(Capsule())
                }

                Text(type.description)
                    .font(.system(size: 12, weight: .medium, design: .rounded))
                    .foregroundStyle(.white.opacity(0.82))
            }

            Spacer()

            Button {
                engine.buyUpgrade(type)
            } label: {
                Text("\(Int(price))")
                    .font(.system(size: 14, weight: .heavy, design: .rounded))
                    .foregroundStyle(affordable ? .black : .white.opacity(0.5))
                    .padding(.horizontal, 14)
                    .padding(.vertical, 10)
                    .background(
                        affordable
                        ? AnyShapeStyle(LinearGradient(colors: [Color(red: 0.55, green: 1.0, blue: 0.35), Color.cyan], startPoint: .topLeading, endPoint: .bottomTrailing))
                        : AnyShapeStyle(Color.white.opacity(0.15))
                    )
                    .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
            }
            .disabled(!affordable)
        }
        .padding(12)
        .liquidGlass(cornerRadius: 22, tint: affordable ? .green : .white)
    }
}
