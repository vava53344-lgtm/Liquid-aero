import SwiftUI

enum BubbleKind: CaseIterable {
    case classicAqua
    case aeroLime
    case crystalCyan
    case goldenOrb

    var primaryColor: Color {
        switch self {
        case .classicAqua: return Color(red: 0.15, green: 0.78, blue: 1.0)
        case .aeroLime: return Color(red: 0.45, green: 0.95, blue: 0.25)
        case .crystalCyan: return Color(red: 0.30, green: 0.95, blue: 0.90)
        case .goldenOrb: return Color(red: 1.0, green: 0.84, blue: 0.15)
        }
    }

    var secondaryColor: Color {
        switch self {
        case .classicAqua: return Color(red: 0.0, green: 0.45, blue: 0.95)
        case .aeroLime: return Color(red: 0.10, green: 0.70, blue: 0.25)
        case .crystalCyan: return Color(red: 0.10, green: 0.65, blue: 0.85)
        case .goldenOrb: return Color(red: 1.0, green: 0.50, blue: 0.0)
        }
    }

    var baseMultiplier: Double {
        switch self {
        case .classicAqua: return 1.0
        case .aeroLime: return 1.5
        case .crystalCyan: return 2.0
        case .goldenOrb: return 5.0
        }
    }
}

struct BubbleEntity: Identifiable {
    let id = UUID()
    var x: CGFloat
    var y: CGFloat
    var radius: CGFloat
    var speedY: CGFloat
    var wobblePhase: CGFloat
    var wobbleAmplitude: CGFloat
    var kind: BubbleKind
    var scale: CGFloat = 0.2
    var opacity: Double = 0.95
}

struct PopParticle: Identifiable {
    let id = UUID()
    var x: CGFloat
    var y: CGFloat
    var vx: CGFloat
    var vy: CGFloat
    var size: CGFloat
    var color: Color
    var life: Double = 1.0
}

struct FloatingScore: Identifiable {
    let id = UUID()
    var x: CGFloat
    var y: CGFloat
    var text: String
    var color: Color
    var life: Double = 1.0
}

enum UpgradeType: String, CaseIterable, Identifiable {
    case tapPower = "Сила касания"
    case bubbleStream = "Поток пузырей"
    case autoPopper = "Авто-лопатель"
    case aeroHarmony = "Гармония Aero"

    var id: String { rawValue }

    var icon: String {
        switch self {
        case .tapPower: return "hand.tap.fill"
        case .bubbleStream: return "bubbles.and.sparkles.fill"
        case .autoPopper: return "wand.and.stars"
        case .aeroHarmony: return "leaf.fill"
        }
    }

    var description: String {
        switch self {
        case .tapPower: return "+Очки за каждый лопнутый пузырь"
        case .bubbleStream: return "Больше пузырей и золотых сфер"
        case .autoPopper: return "Автоматически лопает пузыри в секунду"
        case .aeroHarmony: return "Умножает весь доход Aero-энергии"
        }
    }
}
