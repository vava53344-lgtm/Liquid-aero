import SwiftUI

struct FrutigerAeroWallpaperView: View {
    @State private var animatePhase: Bool = false

    var body: some View {
        GeometryReader { geo in
            ZStack {
                // 1. Deep Vibrant Aero Sky-to-Ocean Gradient
                LinearGradient(
                    colors: [
                        Color(red: 0.02, green: 0.36, blue: 0.78),
                        Color(red: 0.08, green: 0.68, blue: 0.94),
                        Color(red: 0.25, green: 0.88, blue: 0.85),
                        Color(red: 0.32, green: 0.85, blue: 0.35),
                        Color(red: 0.12, green: 0.62, blue: 0.22)
                    ],
                    startPoint: .top,
                    endPoint: .bottom
                )

                // 2. Radiant Sunburst & Lens Flare in Top Right
                Circle()
                    .fill(
                        RadialGradient(
                            colors: [
                                Color.white.opacity(0.95),
                                Color(red: 0.75, green: 0.98, blue: 1.0).opacity(0.55),
                                Color.clear
                            ],
                            center: .center,
                            startRadius: 5,
                            endRadius: geo.size.width * 0.65
                        )
                    )
                    .frame(width: geo.size.width * 1.2, height: geo.size.width * 1.2)
                    .position(x: geo.size.width * 0.82, y: geo.size.height * 0.12)
                    .scaleEffect(animatePhase ? 1.06 : 0.96)

                // 3. Flowing Translucent Aurora / Windows Vista / 7 Light Ribbons
                AeroLightRibbon(phaseOffset: animatePhase ? 25 : -25)
                    .fill(
                        LinearGradient(
                            colors: [
                                Color.white.opacity(0.32),
                                Color(red: 0.45, green: 1.0, blue: 0.85).opacity(0.22),
                                Color.clear
                            ],
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        )
                    )
                    .blur(radius: 8)

                AeroLightRibbon(phaseOffset: animatePhase ? -30 : 30)
                    .fill(
                        LinearGradient(
                            colors: [
                                Color(red: 0.65, green: 0.95, blue: 1.0).opacity(0.28),
                                Color(red: 0.55, green: 1.0, blue: 0.45).opacity(0.18),
                                Color.clear
                            ],
                            startPoint: .leading,
                            endPoint: .trailing
                        )
                    )
                    .offset(y: 70)
                    .blur(radius: 6)

                // 4. Bokeh Water Droplets & Soft Sunlight Orbs
                Circle()
                    .fill(Color.white.opacity(0.18))
                    .frame(width: 140, height: 140)
                    .blur(radius: 12)
                    .position(x: geo.size.width * 0.2, y: geo.size.height * 0.26)

                Circle()
                    .fill(Color(red: 0.6, green: 1.0, blue: 0.7).opacity(0.22))
                    .frame(width: 190, height: 190)
                    .blur(radius: 18)
                    .position(x: geo.size.width * 0.75, y: geo.size.height * 0.52)

                // 5. Lush Frutiger Aero Rolling Green Hills & Glossy Water Horizon at Bottom
                VStack(spacing: 0) {
                    Spacer()
                    ZStack(alignment: .bottom) {
                        // Back Hill
                        AeroHillShape(crestHeight: 0.35, peakX: 0.25)
                            .fill(
                                LinearGradient(
                                    colors: [
                                        Color(red: 0.48, green: 0.94, blue: 0.22),
                                        Color(red: 0.14, green: 0.68, blue: 0.20)
                                    ],
                                    startPoint: .top,
                                    endPoint: .bottom
                                )
                            )
                            .frame(height: geo.size.height * 0.28)

                        // Front Glossy Hill
                        AeroHillShape(crestHeight: 0.45, peakX: 0.78)
                            .fill(
                                LinearGradient(
                                    colors: [
                                        Color(red: 0.62, green: 0.98, blue: 0.32),
                                        Color(red: 0.10, green: 0.58, blue: 0.18)
                                    ],
                                    startPoint: .top,
                                    endPoint: .bottom
                                )
                            )
                            .frame(height: geo.size.height * 0.23)

                        // Water Reflection Sheen at very bottom
                        LinearGradient(
                            colors: [
                                Color.clear,
                                Color(red: 0.05, green: 0.55, blue: 0.85).opacity(0.65)
                            ],
                            startPoint: .top,
                            endPoint: .bottom
                        )
                        .frame(height: geo.size.height * 0.10)
                    }
                }
            }
            .ignoresSafeArea()
            .onAppear {
                withAnimation(.easeInOut(duration: 6.0).repeatForever(autoreverses: true)) {
                    animatePhase.toggle()
                }
            }
        }
    }
}

struct AeroLightRibbon: Shape {
    var phaseOffset: CGFloat

    var animatableData: CGFloat {
        get { phaseOffset }
        set { phaseOffset = newValue }
    }

    func path(in rect: CGRect) -> Path {
        var path = Path()
        let h = rect.height
        let w = rect.width

        path.move(to: CGPoint(x: -40, y: h * 0.28))
        path.addCurve(
            to: CGPoint(x: w + 40, y: h * 0.18),
            control1: CGPoint(x: w * 0.35, y: h * 0.10 + phaseOffset),
            control2: CGPoint(x: w * 0.65, y: h * 0.42 - phaseOffset)
        )
        path.addLine(to: CGPoint(x: w + 40, y: h * 0.36))
        path.addCurve(
            to: CGPoint(x: -40, y: h * 0.46),
            control1: CGPoint(x: w * 0.65, y: h * 0.56 - phaseOffset),
            control2: CGPoint(x: w * 0.35, y: h * 0.24 + phaseOffset)
        )
        path.closeSubpath()
        return path
    }
}

struct AeroHillShape: Shape {
    var crestHeight: CGFloat
    var peakX: CGFloat

    func path(in rect: CGRect) -> Path {
        var path = Path()
        path.move(to: CGPoint(x: 0, y: rect.height))
        path.addLine(to: CGPoint(x: 0, y: rect.height * (1.0 - crestHeight * 0.6)))
        path.addQuadCurve(
            to: CGPoint(x: rect.width, y: rect.height * (1.0 - crestHeight * 0.5)),
            control: CGPoint(x: rect.width * peakX, y: 0)
        )
        path.addLine(to: CGPoint(x: rect.width, y: rect.height))
        path.closeSubpath()
        return path
    }
}
