import SwiftUI
import Combine

@MainActor
final class AeroGameEngine: ObservableObject {
    @Published var energy: Double = 0
    @Published var totalEarned: Double = 0
    @Published var bubblesPopped: Int = 0
    @Published var bubbles: [BubbleEntity] = []
    @Published var particles: [PopParticle] = []
    @Published var floatingScores: [FloatingScore] = []
    @Published var hasWon: Bool = false
    @Published var showWinBanner: Bool = false
    @Published var endlessMode: Bool = false

    // Upgrade levels
    @Published var tapPowerLevel: Int = 1
    @Published var streamLevel: Int = 1
    @Published var autoPopLevel: Int = 0
    @Published var harmonyLevel: Int = 1

    // Target goal to win the game: 25,000 Aero Energy
    let winGoal: Double = 25000.0

    var screenSize: CGSize = CGSize(width: 390, height: 844)
    private var timer: Timer?
    private var spawnAccumulator: Double = 0
    private var autoPopAccumulator: Double = 0

    var progressToWin: Double {
        min(totalEarned / winGoal, 1.0)
    }

    var pointsPerPop: Double {
        let base = Double(tapPowerLevel) * 4.0
        let harmonyMult = 1.0 + Double(harmonyLevel - 1) * 0.35
        return base * harmonyMult
    }

    var spawnInterval: Double {
        max(0.22, 0.95 - Double(streamLevel - 1) * 0.08)
    }

    var maxBubblesOnScreen: Int {
        min(36, 12 + streamLevel * 2)
    }

    var autoPopRate: Double {
        Double(autoPopLevel) * 0.85
    }

    func start() {
        stop()
        // Spawn initial wave
        for _ in 0..<6 {
            spawnBubble(randomY: true)
        }
        timer = Timer.scheduledTimer(withTimeInterval: 1.0 / 60.0, repeats: true) { [weak self] _ in
            Task { @MainActor in
                self?.tick(dt: 1.0 / 60.0)
            }
        }
    }

    func stop() {
        timer?.invalidate()
        timer = nil
    }

    func resetGame() {
        energy = 0
        totalEarned = 0
        bubblesPopped = 0
        tapPowerLevel = 1
        streamLevel = 1
        autoPopLevel = 0
        harmonyLevel = 1
        hasWon = false
        showWinBanner = false
        endlessMode = false
        bubbles.removeAll()
        particles.removeAll()
        floatingScores.removeAll()
        for _ in 0..<6 {
            spawnBubble(randomY: true)
        }
    }

    private func tick(dt: Double) {
        let width = max(screenSize.width, 300)
        let height = max(screenSize.height, 600)

        // Spawning
        spawnAccumulator += dt
        if spawnAccumulator >= spawnInterval && bubbles.count < maxBubblesOnScreen {
            spawnAccumulator = 0
            spawnBubble(randomY: false)
        }

        // Auto-pop logic
        if autoPopLevel > 0 && !bubbles.isEmpty {
            autoPopAccumulator += dt * autoPopRate
            if autoPopAccumulator >= 1.0 {
                autoPopAccumulator -= 1.0
                if let target = bubbles.randomElement() {
                    popBubble(id: target.id, isAuto: true)
                }
            }
        }

        // Update bubbles
        for i in bubbles.indices.reversed() {
            bubbles[i].y -= bubbles[i].speedY * CGFloat(dt)
            bubbles[i].wobblePhase += CGFloat(dt) * 2.4
            bubbles[i].x += sin(bubbles[i].wobblePhase) * bubbles[i].wobbleAmplitude * CGFloat(dt)

            if bubbles[i].scale < 1.0 {
                bubbles[i].scale = min(1.0, bubbles[i].scale + CGFloat(dt) * 3.5)
            }

            // Keep inside horizontal bounds softly
            let r = bubbles[i].radius
            if bubbles[i].x < r + 8 { bubbles[i].x = r + 8 }
            if bubbles[i].x > width - r - 8 { bubbles[i].x = width - r - 8 }

            // Remove if floated past top
            if bubbles[i].y < -r * 2 {
                bubbles.remove(at: i)
            }
        }

        // Update particles
        for i in particles.indices.reversed() {
            particles[i].x += particles[i].vx * CGFloat(dt)
            particles[i].y += particles[i].vy * CGFloat(dt)
            particles[i].vy += 120 * CGFloat(dt) // gentle gravity
            particles[i].life -= dt * 2.2
            if particles[i].life <= 0 {
                particles.remove(at: i)
            }
        }

        // Update floating scores
        for i in floatingScores.indices.reversed() {
            floatingScores[i].y -= 48 * CGFloat(dt)
            floatingScores[i].life -= dt * 1.4
            if floatingScores[i].life <= 0 {
                floatingScores.remove(at: i)
            }
        }
    }

    func spawnBubble(randomY: Bool) {
        let width = max(screenSize.width, 320)
        let height = max(screenSize.height, 640)

        let goldenChance = min(0.05 + Double(streamLevel - 1) * 0.025, 0.30)
        let roll = Double.random(in: 0...1)
        let kind: BubbleKind
        if roll < goldenChance {
            kind = .goldenOrb
        } else if roll < goldenChance + 0.25 {
            kind = .crystalCyan
        } else if roll < goldenChance + 0.55 {
            kind = .aeroLime
        } else {
            kind = .classicAqua
        }

        let radius: CGFloat = kind == .goldenOrb ? CGFloat.random(in: 28...36) : CGFloat.random(in: 30...48)
        let x = CGFloat.random(in: (radius + 16)...(width - radius - 16))
        let y = randomY ? CGFloat.random(in: 140...(height - 160)) : height + radius + 10
        let speedY = CGFloat.random(in: 55...115) + CGFloat(streamLevel) * 4.0

        let entity = BubbleEntity(
            x: x,
            y: y,
            radius: radius,
            speedY: speedY,
            wobblePhase: CGFloat.random(in: 0...(2 * .pi)),
            wobbleAmplitude: CGFloat.random(in: 14...32),
            kind: kind
        )
        bubbles.append(entity)
    }

    func popBubble(id: UUID, isAuto: Bool = false) {
        guard let index = bubbles.firstIndex(where: { $0.id == id }) else { return }
        let bubble = bubbles.remove(at: index)

        let gained = (pointsPerPop * bubble.kind.baseMultiplier).rounded()
        energy += gained
        totalEarned += gained
        bubblesPopped += 1

        let pitch = Float(40.0 / max(bubble.radius, 25.0))
        SoundHapticManager.shared.playPop(pitchMultiplier: pitch, isGolden: bubble.kind == .goldenOrb)

        // Spawn water/glass splash droplets
        let count = bubble.kind == .goldenOrb ? 14 : 9
        for _ in 0..<count {
            let angle = CGFloat.random(in: 0...(2 * .pi))
            let speed = CGFloat.random(in: 60...190)
            let particle = PopParticle(
                x: bubble.x,
                y: bubble.y,
                vx: cos(angle) * speed,
                vy: sin(angle) * speed - 30,
                size: CGFloat.random(in: 4...9),
                color: bubble.kind == .goldenOrb ? .yellow : .white
            )
            particles.append(particle)
        }

        // Floating score popup
        let label = "+\(Int(gained))"
        floatingScores.append(
            FloatingScore(
                x: bubble.x,
                y: bubble.y,
                text: label,
                color: bubble.kind == .goldenOrb ? Color(red: 1.0, green: 0.92, blue: 0.35) : .white
            )
        )

        // Check victory condition
        if !hasWon && totalEarned >= winGoal {
            hasWon = true
            showWinBanner = true
            SoundHapticManager.shared.playWin()
        }
    }

    // MARK: - Upgrades
    func level(for type: UpgradeType) -> Int {
        switch type {
        case .tapPower: return tapPowerLevel
        case .bubbleStream: return streamLevel
        case .autoPopper: return autoPopLevel
        case .aeroHarmony: return harmonyLevel
        }
    }

    func cost(for type: UpgradeType) -> Double {
        let lvl = level(for: type)
        switch type {
        case .tapPower:
            return (25.0 * pow(1.55, Double(lvl - 1))).rounded()
        case .bubbleStream:
            return (45.0 * pow(1.65, Double(lvl - 1))).rounded()
        case .autoPopper:
            return (90.0 * pow(1.75, Double(lvl))).rounded()
        case .aeroHarmony:
            return (150.0 * pow(1.85, Double(lvl - 1))).rounded()
        }
    }

    func canAfford(_ type: UpgradeType) -> Bool {
        energy >= cost(for: type)
    }

    func buyUpgrade(_ type: UpgradeType) {
        let price = cost(for: type)
        guard energy >= price else { return }
        energy -= price

        switch type {
        case .tapPower: tapPowerLevel += 1
        case .bubbleStream: streamLevel += 1
        case .autoPopper: autoPopLevel += 1
        case .aeroHarmony: harmonyLevel += 1
        }
        SoundHapticManager.shared.playUpgrade()
    }
}
