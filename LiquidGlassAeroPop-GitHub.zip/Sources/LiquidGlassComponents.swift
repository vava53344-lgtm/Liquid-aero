import SwiftUI

// Authentic iOS 26+ Liquid Glass Container Modifier
struct LiquidGlassModifier: ViewModifier {
    var cornerRadius: CGFloat = 24
    var tint: Color = .white

    func body(content: Content) -> some View {
        content
            .background {
                ZStack {
                    RoundedRectangle(cornerRadius: cornerRadius, style: .continuous)
                        .fill(.ultraThinMaterial)

                    RoundedRectangle(cornerRadius: cornerRadius, style: .continuous)
                        .fill(
                            LinearGradient(
                                colors: [
                                    tint.opacity(0.28),
                                    tint.opacity(0.06),
                                    Color.white.opacity(0.14)
                                ],
                                startPoint: .topLeading,
                                endPoint: .bottomTrailing
                            )
                        )

                    // Top Glossy Specular Highlight (Liquid Glass refraction rim)
                    RoundedRectangle(cornerRadius: cornerRadius, style: .continuous)
                        .strokeBorder(
                            LinearGradient(
                                colors: [
                                    Color.white.opacity(0.85),
                                    Color.white.opacity(0.25),
                                    Color.white.opacity(0.08),
                                    Color.white.opacity(0.55)
                                ],
                                startPoint: .topLeading,
                                endPoint: .bottomTrailing
                            ),
                            lineWidth: 1.4
                        )
                }
                .shadow(color: Color.black.opacity(0.16), radius: 14, x: 0, y: 8)
            }
    }
}

extension View {
    func liquidGlass(cornerRadius: CGFloat = 24, tint: Color = .white) -> some View {
        modifier(LiquidGlassModifier(cornerRadius: cornerRadius, tint: tint))
    }
}

// Liquid Glass Interactive Soap/Water Bubble
struct LiquidGlassBubbleView: View {
    let bubble: BubbleEntity
    let onPop: () -> Void

    var body: some View {
        let diameter = bubble.radius * 2
        ZStack {
            // Translucent Refractive Body
            Circle()
                .fill(
                    RadialGradient(
                        colors: [
                            Color.white.opacity(0.08),
                            bubble.kind.primaryColor.opacity(0.22),
                            bubble.kind.secondaryColor.opacity(0.48)
                        ],
                        center: .center,
                        startRadius: diameter * 0.05,
                        endRadius: diameter * 0.5
                    )
                )

            // Iridescent Rim
            Circle()
                .strokeBorder(
                    LinearGradient(
                        colors: [
                            Color.white.opacity(0.95),
                            bubble.kind.primaryColor.opacity(0.6),
                            Color.white.opacity(0.2),
                            Color.white.opacity(0.8)
                        ],
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    ),
                    lineWidth: bubble.kind == .goldenOrb ? 2.5 : 1.8
                )

            // Classic Frutiger Aero Glossy Crescent Highlight (Top-Left)
            Ellipse()
                .fill(
                    LinearGradient(
                        colors: [
                            Color.white.opacity(0.92),
                            Color.white.opacity(0.15)
                        ],
                        startPoint: .top,
                        endPoint: .bottom
                    )
                )
                .frame(width: diameter * 0.52, height: diameter * 0.26)
                .rotationEffect(.degrees(-32))
                .offset(x: -diameter * 0.16, y: -diameter * 0.22)

            // Secondary Specular Dot
            Circle()
                .fill(Color.white.opacity(0.85))
                .frame(width: diameter * 0.11, height: diameter * 0.11)
                .offset(x: -diameter * 0.28, y: -diameter * 0.02)

            // Bottom Caustic Bounce Reflection
            Ellipse()
                .fill(bubble.kind.primaryColor.opacity(0.45))
                .frame(width: diameter * 0.45, height: diameter * 0.16)
                .blur(radius: 2)
                .offset(y: diameter * 0.34)

            if bubble.kind == .goldenOrb {
                Image(systemName: "sparkles")
                    .font(.system(size: diameter * 0.32, weight: .bold))
                    .foregroundStyle(.white.opacity(0.9))
            }
        }
        .frame(width: diameter, height: diameter)
        .shadow(color: bubble.kind.primaryColor.opacity(0.35), radius: 8, x: 0, y: 4)
        .scaleEffect(bubble.scale)
        .position(x: bubble.x, y: bubble.y)
        .contentShape(Circle())
        .onTapGesture {
            onPop()
        }
    }
}
